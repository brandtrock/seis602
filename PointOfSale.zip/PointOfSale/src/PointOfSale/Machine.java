package PointOfSale;

public class Machine {

	private int machineNumber = 1;
	
	public int readMachineNumber() {
		
		// TODO - implement multiple machines
		// for now, just return a static number
		
		return machineNumber;
		
	}
	
}
