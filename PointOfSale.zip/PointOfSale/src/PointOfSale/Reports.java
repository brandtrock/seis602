package PointOfSale;

public class Reports {

	// TODO: This class will be used to gather the data from the "TRANSACTIONS" flat-file
	// to generate the different types of reports required for the project.
	
	
	// These methods will need to be built-out
	// the current return type is "void," we'll probably have to change that
	public void inventoryReport() {}
	
	public void cashierReport() {}
	
	public void registerReport() {}
}
